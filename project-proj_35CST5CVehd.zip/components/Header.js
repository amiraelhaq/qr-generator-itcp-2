function Header() {
  return (
    <header className="bg-white border-b sticky top-0 z-50" data-name="header" data-file="components/Header.js">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2 relative">
          <div className="w-10 h-10 bg-gradient-to-br from-[var(--primary-color)] via-[var(--tertiary-color)] to-[var(--accent-color)] rounded-xl flex items-center justify-center shadow-lg shadow-purple-200">
            <div className="icon-qr-code text-white text-2xl"></div>
          </div>
          <span className="text-xl font-bold tracking-tight">QR<span className="text-transparent bg-clip-text bg-gradient-to-r from-[var(--primary-color)] to-[var(--tertiary-color)]">Pro</span></span>
          <div className="icon-heart text-pink-400 text-xs absolute -top-1 -right-3 animate-ping"></div>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#" className="text-gray-600 hover:text-[var(--primary-color)] transition-colors">Generator</a>
          <a href="#" className="text-gray-600 hover:text-[var(--primary-color)] transition-colors">Template</a>
          <a href="#" className="text-gray-600 hover:text-[var(--primary-color)] transition-colors">Pricing</a>
        </nav>
        <div className="flex items-center gap-3">
          <button className="btn btn-outline text-sm py-2 px-4">Masuk</button>
          <button className="btn btn-primary text-sm py-2 px-4">Mulai Gratis</button>
        </div>
      </div>
    </header>
  );
}