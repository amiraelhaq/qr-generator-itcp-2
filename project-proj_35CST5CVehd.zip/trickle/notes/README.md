# QR Pro - Modern QR Code Generator

A professional-grade QR code generation application built with React and Tailwind CSS.

## Features
- Multi-format support (URL, Text, Wi-Fi, vCard)
- Real-time preview
- Custom colors (Foregorund & Background)
- Logo overlay support with error correction optimization
- High-quality PNG download
- Responsive modern UI with Pastel Pink, Blue & Purple theme
- Decorative elements (hearts, flowers, sparkles) for aesthetic appeal

## Maintenance Rules
- Whenever a new feature is added, update this README.
- Ensure `qrHelper.js` handles edge cases for invalid inputs.
- Keep the design consistent with the corporate/modern style template.