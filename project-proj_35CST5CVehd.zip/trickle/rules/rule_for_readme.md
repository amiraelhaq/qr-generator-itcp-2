When project is updated
- Check if project structure or features have changed.
- If changes occur, update `trickle/notes/README.md` to reflect the latest state.
- Keep documentation concise and developer-friendly.